# SwasthyaGrid — Android Assignment Demo

This is an Android demo build of the SwasthyaGrid civic-intelligence prototype.

## What this APK is for
- Demonstrating the existing React screens for an academic assignment.
- Switching among Citizen, Department Officer, Field Officer, Health Analyst, and System Admin roles.
- Using the included sample complaints, audit records, risk analysis and local demo workflows.
- Recording demo actions locally on the phone so they remain after closing/reopening the app.

## Demo-only behavior
This package intentionally runs in offline demonstration mode:
- No live municipal backend, Express server, SQLite service, or Gemini API is required.
- Demo role selection is local and does not verify real government identity.
- Complaint changes and demo records are stored in the app's local browser storage.
- Map tiles and any external web content may still need an internet connection.
- Data is illustrative and must not be represented as live civic or medical surveillance.

## Demo roles
Select a role in the login portal. The app uses built-in demo identities. The password field is not used for offline demo sign-in.

## Build an APK using GitHub Actions from your phone
1. Create a new public or private GitHub repository (for example `SwasthyaGrid-Demo`).
2. Upload this ZIP file to the repository root. Do not extract it in GitHub.
3. Create a new file with this exact path:
   `.github/workflows/build-android-apk.yml`
4. Copy the complete contents of `GITHUB_WORKFLOW.yml` from this project ZIP into that new GitHub file.
5. Commit the file. Open the repository's Actions tab.
6. Open **Build SwasthyaGrid Demo APK** and wait for the green success tick.
7. Open the successful workflow run, go to its Summary page, scroll to **Artifacts**, and download `SwasthyaGrid-Demo-APK`.
8. Extract the downloaded artifact ZIP and install `app-debug.apk` on Android. If prompted, allow installation from that browser/file manager.

## Local build (computer)
Requires Node.js 22, Java 21, Android SDK and Android Studio.

```bash
npm install --legacy-peer-deps
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

APK path:
`android/app/build/outputs/apk/debug/app-debug.apk`

## Important
This is a demonstration prototype for assignment screenshots, not a production deployment. The APK is unsigned with a debug key and is suitable for local testing/assignment demonstration, not Play Store release.
