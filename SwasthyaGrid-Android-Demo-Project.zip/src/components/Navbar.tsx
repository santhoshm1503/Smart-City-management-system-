import React from 'react';
import { useApp } from '../context/AppContext';
import { Globe, LogOut, ShieldCheck, User } from 'lucide-react';

export const Navbar: React.FC = () => {
  const { currentUser, language, setLanguage, logout, t } = useApp();

  const roleLabels = {
    CITIZEN: { en: 'Citizen Portal', ta: 'குடிமக்கள் தளம்' },
    DEPT_OFFICER: { en: 'Representative / Dept Officer', ta: 'துறை அதிகாரி தளம்' },
    FIELD_OFFICER: { en: 'Field Officer Ground Unit', ta: 'களப்பணி அதிகாரி தளம்' },
    HEALTH_ANALYST: { en: 'Epidemiology Analyst', ta: 'சுகாதாரப் பகுப்பாய்வாளர்' },
    SYS_ADMIN: { en: 'System Administrator', ta: 'தலைமை நிர்வாகி' },
  };

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-6">
        {/* Zone 1: Brand Wordmark (Single text element) */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-9 h-9 rounded-lg bg-slate-900 text-teal-400 font-bold flex items-center justify-center text-base tracking-tighter border border-slate-800">
            SG
          </div>
          <div>
            <span className="text-base sm:text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap block">
              {t.platformName}
            </span>
            <span className="text-[10px] text-teal-700 font-semibold tracking-wide block -mt-1">
              {language === 'ta' ? 'தமிழ்நாடு நகராட்சி கட்டமைப்பு' : 'Tamil Nadu Civic Intelligence'}
            </span>
          </div>
        </div>

        {/* Zone 2: Role Access Scope Indicator */}
        <div className="hidden md:flex items-center gap-2 bg-slate-100 border border-slate-200 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700">
          <ShieldCheck className="w-4 h-4 text-teal-600 shrink-0" />
          <span className="font-bold text-slate-900">
            {roleLabels[currentUser.role]?.[language] || currentUser.role}
          </span>
          <span className="text-slate-400">·</span>
          <span className="text-slate-500 font-mono text-[11px]">Ward 10 Chennai</span>
        </div>

        {/* Zone 3: User Profile, Language & Sign Out Action */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Language Switcher */}
          <button
            type="button"
            onClick={() => setLanguage(language === 'en' ? 'ta' : 'en')}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            title="Toggle Language / மொழியை மாற்றுக"
          >
            <Globe className="w-3.5 h-3.5 text-teal-600" />
            <span>{language === 'en' ? 'தமிழ்' : 'English'}</span>
          </button>

          {/* User Profile Pill */}
          <div className="flex items-center gap-2 border-l border-slate-200 pl-3">
            <div className="text-right hidden sm:block">
              <span className="text-xs font-bold text-slate-900 block leading-tight truncate max-w-[130px]">
                {currentUser.name}
              </span>
              <span className="text-[10px] text-teal-700 font-semibold font-mono block leading-tight">
                {currentUser.role}
              </span>
            </div>

            {/* Switch Persona / Role Button */}
            <button
              type="button"
              onClick={logout}
              className="bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 text-xs font-semibold px-2.5 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Switch Persona / வேறு பயனர் பொறுப்பிற்கு மாறுக"
            >
              <User className="w-3.5 h-3.5 text-teal-600" />
              <span className="hidden sm:inline">{language === 'ta' ? 'பொறுப்பு மாற்றம்' : 'Switch Role'}</span>
            </button>

            {/* Sign Out Button */}
            <button
              type="button"
              onClick={logout}
              className="bg-slate-100 hover:bg-rose-50 hover:text-rose-700 hover:border-rose-200 text-slate-700 border border-slate-300 text-xs font-semibold px-2.5 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Sign Out / கணக்கிலிருந்து வெளியேறுக"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{language === 'ta' ? 'வெளியேறுக' : 'Sign Out'}</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
