import React, { useState } from 'react';
import { useApp, PRESET_USERS } from '../context/AppContext';
import { UserRole } from '../types';
import {
  Shield,
  UserCheck,
  Building2,
  HardHat,
  Activity,
  Server,
  Globe,
  ArrowRight,
  Lock,
  Mail,
  CheckCircle2,
  Sparkles,
  Info,
  Eye,
  EyeOff,
  UserPlus,
  Phone,
  MapPin,
  AlertCircle,
  Zap,
  Check,
} from 'lucide-react';

interface RoleMeta {
  role: UserRole;
  titleEn: string;
  titleTa: string;
  badgeEn: string;
  badgeTa: string;
  deptEn: string;
  deptTa: string;
  color: string;
  borderColor: string;
  bgGlow: string;
  icon: React.ComponentType<{ className?: string }>;
  featuresEn: string[];
  featuresTa: string[];
  descriptionEn: string;
  descriptionTa: string;
}

const ROLES_METADATA: Record<UserRole, RoleMeta> = {
  CITIZEN: {
    role: 'CITIZEN',
    titleEn: 'Citizen / Resident',
    titleTa: 'குடிமகன் / குடியிருப்புவாசி',
    badgeEn: 'Public Access',
    badgeTa: 'பொது அணுகல்',
    deptEn: 'Ward 10 Community',
    deptTa: 'வார்டு 10 பொதுமக்கள்',
    color: 'emerald',
    borderColor: 'border-emerald-500/50',
    bgGlow: 'bg-emerald-500/10',
    icon: UserCheck,
    featuresEn: [
      '5-Step AI-Assisted Civic Hazard Wizard (Sewage, Stagnation, Waste)',
      '100m Privacy-Jittered Geospatial Public Risk Map',
      'Community Verification & Upvote Loop',
      'AI Complaint Assistant & SLA Guidelines',
    ],
    featuresTa: [
      '5-படி AI துணையுடன் கூடிய நகராட்சி புகார் பதிவு வழிகாட்டி',
      '100மீ தனியுரிமை பாதுகாப்புடன் கூடிய பொது சுகாதார வரைபடம்',
      'சமூக சரிபார்ப்பு & உறுதிப்படுத்தல் வாக்களிப்பு',
      'AI புகார் வரைவு உதவியாளர் & SLA காலக்கெடு தகவல்',
    ],
    descriptionEn: 'Designed for residents of Chennai Ward 10 to lodge geo-tagged infrastructure hazards, monitor real-time SLA progress, and confirm field resolution.',
    descriptionTa: 'சென்னை வார்டு 10 குடியிருப்புவாசிகள் சுகாதாரக் குறைபாடுகளைப் பதிவு செய்யவும், களப்பணி தீர்வை உறுதிப்படுத்தவும் பிரத்யேகமாக உருவாக்கப்பட்டது.',
  },
  FIELD_OFFICER: {
    role: 'FIELD_OFFICER',
    titleEn: 'Field Officer Ground Unit',
    titleTa: 'களப்பணி அதிகாரி',
    badgeEn: 'Ground Operations',
    badgeTa: 'களப்பணி இயக்கம்',
    deptEn: 'Storm Water Drainage (SWD) / Vector Wing',
    deptTa: 'மழைநீர் வடிகால் & கொசுப்புழு தடுப்புப் பிரிவு',
    color: 'amber',
    borderColor: 'border-amber-500/50',
    bgGlow: 'bg-amber-500/10',
    icon: HardHat,
    featuresEn: [
      'Dispatched Work Order Queue & On-Site Triage',
      'Before & After Photographic Verification Upload',
      'Intervention Recording (Desilting, BTI Larvicide, Chlorination)',
      'Mobile-Optimized Field Task Progression Workflow',
    ],
    featuresTa: [
      'ஒதுக்கப்பட்ட களப்பணி வரிசை & உடனடி கள ஆய்வு',
      'பணிக்கு முந்தைய மற்றும் பிந்தைய புகைப்படங்கள் பதிவேற்றம்',
      'தூர்வாருதல் & கொசு மருந்து தெளிப்பு பதிவு',
      'மொபைல் பயன்பாட்டிற்கு உகந்த பணி முன்னேற்ற தளம்',
    ],
    descriptionEn: 'Operational console for GCC sanitary inspectors and drainage field crews to log interventions, progress ticket states, and submit resolution proof.',
    descriptionTa: 'மாநகராட்சி துப்புரவு ஆய்வாளர்கள் மற்றும் வடிகால் களப்பணியாளர்கள் தூர்வாருதல் பணிகளைப் பதிவு செய்ய உகந்தது.',
  },
  DEPT_OFFICER: {
    role: 'DEPT_OFFICER',
    titleEn: 'Ward Representative / Dept Officer',
    titleTa: 'துறை அதிகாரி / மக்கள் பிரதிநிதி',
    badgeEn: 'Dispatch Authority',
    badgeTa: 'ஒதுக்கீட்டு அதிகாரம்',
    deptEn: 'CMWSSB & GCC Engineering',
    deptTa: 'சென்னை குடிநீர் வாரியம் & பொறியியல் துறை',
    color: 'teal',
    borderColor: 'border-teal-500/50',
    bgGlow: 'bg-teal-500/10',
    icon: Building2,
    featuresEn: [
      'Ward-Wide SLA Countdown Timers & Escalation Board',
      'Officer Dispatch Assignment & Task Delegation',
      'Unjittered Precision Subterranean Geospatial View',
      'Duplicate Cluster Inspection & Triage Approval',
    ],
    featuresTa: [
      'வார்டு அளவிலான SLA காலக்கெடு கண்காணிப்பு பலகை',
      'கள அதிகாரிகளுக்கு பணி ஒதுக்கீடு மற்றும் கண்காணிப்பு',
      'துல்லியமான பூகோள வரைபடம் மற்றும் கழிவுநீர் கட்டமைப்பு',
      'ஒரே இடத்திலான பல புகார்களை ஒன்றிணைத்து ஆய்வு செய்தல்',
    ],
    descriptionEn: 'Administrative dashboard for GCC Assistant Engineers and ward councilors to enforce SLAs, triage high-priority hazards, and dispatch field teams.',
    descriptionTa: 'உதவி செயற்பொறியாளர்கள் மற்றும் மக்கள் பிரதிநிதிகள் புகார்களை முன்னுரிமைப்படுத்தி பணியாளர்களை நியமிக்கும் தளம்.',
  },
  HEALTH_ANALYST: {
    role: 'HEALTH_ANALYST',
    titleEn: 'Epidemiology & Risk Analyst',
    titleTa: 'சுகாதார இடர் பகுப்பாய்வாளர்',
    badgeEn: 'Surveillance Wing',
    badgeTa: 'கண்காணிப்புப் பிரிவு',
    deptEn: 'Public Health Surveillance',
    deptTa: 'பொது சுகாதாரக் கண்காணிப்பு பிரிவு',
    color: 'indigo',
    borderColor: 'border-indigo-500/50',
    bgGlow: 'bg-indigo-500/10',
    icon: Activity,
    featuresEn: [
      'DBSCAN Spatial Cluster Outbreak Detection',
      'Reproduction Risk (R0) Multi-Hazard Calculations',
      'Intervention Efficacy Pre/Post Reassessment Formula',
      'Evidence-Gap Prioritized Ground Inspection Engine',
    ],
    featuresTa: [
      'DBSCAN விண்வெளி கிளஸ்டர் நோய் பரவல் கணிப்பு',
      'தொற்று பரவல் இடர் (R0) பன்முக கணக்கீட்டு மாதிரி',
      'களப்பணிக்கு முந்தைய/பிந்தைய பயன் ஆய்வு சமன்பாடு',
      'ஆதார இடைவெளி முன்னுரிமை ஆய்வு பரிந்துரை இயந்திரம்',
    ],
    descriptionEn: 'Scientific epidemiology lab for public health officers to identify emerging disease vectors, spatial density spikes, and intervention effectiveness.',
    descriptionTa: 'பொது சுகாதார வல்லுநர்கள் கொசுப்புழு பரவல் மற்றும் தொற்று நோய்கள் பரவாமல் தடுக்க இடர் பகுப்பாய்வு செய்யும் ஆய்வகம்.',
  },
  SYS_ADMIN: {
    role: 'SYS_ADMIN',
    titleEn: 'System Administrator',
    titleTa: 'கணினி தலைமை நிர்வாகி',
    badgeEn: 'Governance & Security',
    badgeTa: 'பாதுகாப்பு & தணிக்கை',
    deptEn: 'Greater Chennai Corporation HQ',
    deptTa: 'பெருநகர சென்னை மாநகராட்சி தலைமையகம்',
    color: 'rose',
    borderColor: 'border-rose-500/50',
    bgGlow: 'bg-rose-500/10',
    icon: Server,
    featuresEn: [
      'Cryptographically Verified Immutable Audit Ledger',
      'Role-Based Access Control (RBAC) Enforcement',
      'Database Integrity Diagnostics & SQLite Persistence',
      'Tamper-Evident Security Log Inspections',
    ],
    featuresTa: [
      'கிரிப்டோகிராஃபிக் பாதுகாப்புடன் கூடிய மாற்ற முடியாத தணிக்கை பதிவேடு',
      'பயனர் பொறுப்பு சார்ந்த பாதுகாப்பு விதிமுறைகள் (RBAC)',
      'SQLite தரவுத்தள தொடர்ச்சி மற்றும் கணினி நலன்',
      'பாதுகாப்பு அத்துமீறல் கண்காணிப்பு மற்றும் அறிக்கை',
    ],
    descriptionEn: 'Governance terminal for municipal IT administrators to audit all state transitions, manage RBAC boundaries, and export compliance records.',
    descriptionTa: 'அனைத்து நகராட்சி செயல்பாடுகள், தரவுத்தள மாற்றங்கள் மற்றும் பாதுகாப்பு பதிவுகளைத் தணிக்கை செய்யும் நிர்வாகத் தளம்.',
  },
};

export const LoginPortal: React.FC = () => {
  const { login, registerCitizen, language, setLanguage, t } = useApp();

  const [selectedRole, setSelectedRole] = useState<UserRole>('CITIZEN');
  const [authMode, setAuthMode] = useState<'LOGIN' | 'REGISTER'>('LOGIN');

  // Login form state
  const [email, setEmail] = useState<string>(PRESET_USERS.CITIZEN.defaultEmail);
  const [password, setPassword] = useState<string>('password123');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [rememberMe, setRememberMe] = useState<boolean>(true);

  // Citizen registration state
  const [regFullName, setRegFullName] = useState<string>('');
  const [regEmail, setRegEmail] = useState<string>('');
  const [regPhone, setRegPhone] = useState<string>('');
  const [regPassword, setRegPassword] = useState<string>('');
  const [regConfirmPassword, setRegConfirmPassword] = useState<string>('');

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const activeMeta = ROLES_METADATA[selectedRole];
  const activePreset = PRESET_USERS[selectedRole];

  const handleRoleSelect = (role: UserRole) => {
    setSelectedRole(role);
    setEmail(PRESET_USERS[role].defaultEmail);
    setPassword('password123');
    setErrorMsg(null);
    if (role !== 'CITIZEN' && authMode === 'REGISTER') {
      setAuthMode('LOGIN');
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMsg(null);

    try {
      const ok = await login(email.trim(), password, selectedRole);
      if (!ok) {
        setErrorMsg(
          language === 'ta'
            ? 'உள்நுழைவு தோல்வியடைந்தது. கடவுச்சொல்லை சரிபார்க்கவும் (மாதிரி கணக்குகளுக்கு: password123).'
            : 'Authentication failed. Please verify credentials (for official demo accounts: password123).'
        );
      }
    } catch {
      setErrorMsg(
        language === 'ta'
          ? 'பாதுகாப்பு சேவையகத்துடன் இணைக்க முடியவில்லை. மீண்டும் முயற்சிக்கவும்.'
          : 'Network error connecting to municipal authentication server.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!regFullName.trim() || !regEmail.trim() || !regPassword) {
      setErrorMsg(language === 'ta' ? 'அனைத்து விவரங்களையும் பூர்த்தி செய்யவும்.' : 'Please fill in all required fields.');
      return;
    }

    if (regPassword.length < 6) {
      setErrorMsg(language === 'ta' ? 'கடவுச்சொல் குறைந்தது 6 எழுத்துகள் இருக்க வேண்டும்.' : 'Password must be at least 6 characters.');
      return;
    }

    if (regPassword !== regConfirmPassword) {
      setErrorMsg(language === 'ta' ? 'கடவுச்சொற்கள் பொருந்தவில்லை.' : 'Passwords do not match.');
      return;
    }

    setIsLoading(true);
    try {
      const success = await registerCitizen(regEmail.trim(), regPassword, regFullName.trim(), regPhone.trim());
      if (!success) {
        setErrorMsg(
          language === 'ta'
            ? 'பதிவு செய்ய முடியவில்லை. இந்த மின்னஞ்சல் ஏற்கனவே பயன்பாட்டில் இருக்கலாம்.'
            : 'Registration failed. This email may already be registered.'
        );
      }
    } catch {
      setErrorMsg('Network error during registration.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickLogin = async (role: UserRole) => {
    handleRoleSelect(role);
    setIsLoading(true);
    setErrorMsg(null);
    await login(PRESET_USERS[role].defaultEmail, 'password123', role);
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-slate-100 flex flex-col justify-between font-sans selection:bg-teal-500 selection:text-white">
      {/* 1. Official State & Academic Header */}
      <header className="bg-slate-950/95 border-b border-slate-800/80 px-4 sm:px-8 py-2.5 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-3">
          <div className="flex items-center gap-3">
            <span className="bg-amber-500/20 text-amber-300 font-bold px-2.5 py-0.5 rounded-full border border-amber-500/40 text-[10px] tracking-wider uppercase">
              Academic Demonstration
            </span>
            <span className="hidden sm:inline text-slate-400 text-xs">
              Tamil Nadu Urban Sanitation Framework · Chennai Central Ward 10
            </span>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-1.5 text-xs text-teal-400 bg-teal-950/40 px-2.5 py-1 rounded-md border border-teal-800/50">
              <Shield className="w-3.5 h-3.5" />
              <span>PBKDF2 Hashing & HMAC Signed Sessions</span>
            </div>

            {/* Language Selector */}
            <button
              type="button"
              onClick={() => setLanguage(language === 'en' ? 'ta' : 'en')}
              className="flex items-center gap-1.5 text-xs text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 px-3 py-1 rounded-lg border border-slate-700 transition-colors cursor-pointer"
            >
              <Globe className="w-3.5 h-3.5 text-teal-400" />
              <span className="font-semibold">{language === 'en' ? 'தமிழ் (TA)' : 'English (EN)'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* 2. Main Portal Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 flex flex-col items-center justify-center">
        {/* Emblem & Portal Brand */}
        <div className="text-center max-w-2xl mx-auto mb-6 space-y-2">
          <div className="inline-flex items-center justify-center p-2 rounded-2xl bg-gradient-to-tr from-slate-900 via-teal-950 to-slate-800 border border-teal-500/30 shadow-xl shadow-teal-950/40 mb-1">
            <div className="w-12 h-12 rounded-xl bg-slate-950 flex items-center justify-center text-teal-400 font-black text-xl tracking-tighter border border-teal-500/40">
              SG
            </div>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white flex items-center justify-center gap-2 flex-wrap">
            <span>{t.platformName}</span>
            <span className="text-teal-400 text-xl font-normal">(ஸ்வஸ்த்யாகிரிட்)</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 max-w-lg mx-auto">
            {language === 'ta'
              ? 'பெருநகர சென்னை மாநகராட்சி வார்டு 10 · தனித்துவமான பயனர் தளங்களுக்கான பாதுகாப்பான உள்நுழைவு போர்டல்'
              : 'Greater Chennai Corporation Ward 10 · Secure Multi-Role Portal for Citizens & Municipal Authorities'}
          </p>
        </div>

        {/* 3. Role-Selector Tabs (5 Roles) */}
        <div className="w-full max-w-5xl mb-6">
          <div className="flex items-center justify-between mb-2 px-1">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-teal-400" />
              {language === 'ta' ? 'அங்கீகரிக்கப்பட்ட பயனர் பொறுப்பைத் தேர்ந்தெடுக்கவும்:' : 'Select Authorized Persona:'}
            </span>
            <span className="text-[11px] text-teal-400 font-medium hidden sm:inline">
              {language === 'ta' ? 'தேர்ந்தெடுத்த பொறுப்பின் அம்சங்கள் மட்டுமே திறக்கும்' : 'Strict Role Feature Isolation Active'}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
            {(Object.keys(ROLES_METADATA) as UserRole[]).map(r => {
              const meta = ROLES_METADATA[r];
              const Icon = meta.icon;
              const isSelected = selectedRole === r;
              return (
                <button
                  key={r}
                  type="button"
                  onClick={() => handleRoleSelect(r)}
                  className={`p-3 rounded-xl border text-left transition-all duration-150 cursor-pointer flex flex-col justify-between gap-2 relative overflow-hidden ${
                    isSelected
                      ? 'bg-slate-900 border-teal-400 ring-2 ring-teal-500/40 shadow-lg shadow-teal-950/60'
                      : 'bg-slate-950/70 border-slate-800 hover:border-slate-700 hover:bg-slate-900/60 text-slate-400'
                  }`}
                >
                  {isSelected && (
                    <div className="absolute top-0 right-0 w-8 h-8 overflow-hidden">
                      <div className="bg-teal-500 text-slate-950 w-12 h-4 rotate-45 transform translate-x-3 -translate-y-1 flex items-center justify-center">
                        <Check className="w-2.5 h-2.5 stroke-[3]" />
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between">
                    <div className={`p-2 rounded-lg ${isSelected ? 'bg-teal-500/20 text-teal-300' : 'bg-slate-800/80 text-slate-400'}`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className={`text-[9px] px-1.5 py-0.5 rounded font-mono uppercase tracking-wider ${
                      isSelected ? 'bg-teal-500/20 text-teal-300 font-semibold' : 'bg-slate-900 text-slate-500'
                    }`}>
                      {language === 'ta' ? meta.badgeTa : meta.badgeEn}
                    </span>
                  </div>

                  <div>
                    <h3 className={`text-xs font-bold leading-tight ${isSelected ? 'text-white' : 'text-slate-300'}`}>
                      {language === 'ta' ? meta.titleTa : meta.titleEn}
                    </h3>
                    <p className="text-[10px] text-slate-400 mt-0.5 line-clamp-1">
                      {language === 'ta' ? meta.deptTa : meta.deptEn}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* 4. Main Two-Column Auth Box */}
        <div className="w-full max-w-5xl bg-slate-950/90 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden backdrop-blur-md grid grid-cols-1 lg:grid-cols-12">
          
          {/* Left Column: Role Details & Feature Capabilities (5 cols) */}
          <div className="lg:col-span-5 p-6 bg-gradient-to-br from-slate-900/90 via-slate-950 to-slate-900 border-b lg:border-b-0 lg:border-r border-slate-800 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              {/* Persona Profile Card */}
              <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase font-bold tracking-wider text-teal-400">
                    {language === 'ta' ? 'அதிகாரப்பூர்வ மாதிரி நபர்' : 'Authorized Persona'}
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                    {selectedRole}
                  </span>
                </div>
                <div className="flex items-center gap-3 pt-1">
                  <div className="w-10 h-10 rounded-lg bg-teal-950/80 border border-teal-500/30 flex items-center justify-center text-teal-400 font-bold text-sm shrink-0">
                    {activePreset.name.charAt(0)}
                  </div>
                  <div>
                    <div className="text-sm font-bold text-white">{activePreset.name}</div>
                    <div className="text-[11px] text-slate-400 font-mono">{activePreset.defaultEmail}</div>
                  </div>
                </div>
              </div>

              {/* Scope Description */}
              <div>
                <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                  <Info className="w-3.5 h-3.5 text-teal-400" />
                  {language === 'ta' ? 'பயனர் பொறுப்பின் எல்லை & பணிகள்:' : 'Role Scope & Responsibilities:'}
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {language === 'ta' ? activeMeta.descriptionTa : activeMeta.descriptionEn}
                </p>
              </div>

              {/* Dedicated Features Checklist */}
              <div className="space-y-2 pt-2">
                <h4 className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                  {language === 'ta' ? 'பிரத்யேக அம்சங்கள்:' : 'Exclusive Features Included:'}
                </h4>
                <ul className="space-y-2">
                  {(language === 'ta' ? activeMeta.featuresTa : activeMeta.featuresEn).map((feat, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-teal-400 shrink-0 mt-0.5" />
                      <span className="leading-tight">{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Strict RBAC Assurance */}
            <div className="p-3 rounded-lg bg-teal-950/30 border border-teal-800/40 text-[11px] text-slate-300 space-y-1">
              <span className="font-bold text-teal-300 flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-teal-400" />
                {language === 'ta' ? 'பாதுகாப்பு & தனித்துவம்' : 'Role Boundary Guard'}
              </span>
              <p className="text-[10px] text-slate-400 leading-tight">
                {language === 'ta'
                  ? 'இந்த உள்நுழைவு மூலம் உங்கள் பொறுப்பிற்குரிய திரைகள் மட்டுமே காண்பிக்கப்படும். பிற பயனர்களின் கட்டுப்பாடுகள் தடுக்கப்படும்.'
                  : 'You will land directly on the dedicated workspace for this role. Features belonging to other roles are strictly segregated.'}
              </p>
            </div>
          </div>

          {/* Right Column: Credentials & Authentication Actions (7 cols) */}
          <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-between space-y-6">
            
            {/* Header: Auth Mode Selector (If Citizen: Show Login / Register tabs) */}
            <div>
              {selectedRole === 'CITIZEN' ? (
                <div className="flex border-b border-slate-800 pb-3 mb-4 gap-4">
                  <button
                    type="button"
                    onClick={() => { setAuthMode('LOGIN'); setErrorMsg(null); }}
                    className={`text-xs font-bold pb-1 cursor-pointer transition-colors relative ${
                      authMode === 'LOGIN' ? 'text-teal-400' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {language === 'ta' ? 'குடிமக்கள் உள்நுழைவு' : 'Resident Sign In'}
                    {authMode === 'LOGIN' && (
                      <span className="absolute bottom-[-13px] left-0 w-full h-0.5 bg-teal-400 rounded-full" />
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => { setAuthMode('REGISTER'); setErrorMsg(null); }}
                    className={`text-xs font-bold pb-1 cursor-pointer transition-colors relative flex items-center gap-1.5 ${
                      authMode === 'REGISTER' ? 'text-teal-400' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>{language === 'ta' ? 'புதிய குடிமக்கள் பதிவு' : 'New Citizen Registration'}</span>
                    {authMode === 'REGISTER' && (
                      <span className="absolute bottom-[-13px] left-0 w-full h-0.5 bg-teal-400 rounded-full" />
                    )}
                  </button>
                </div>
              ) : (
                <div className="border-b border-slate-800 pb-3 mb-4 flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-white">
                      {language === 'ta'
                        ? `${activeMeta.titleTa} நற்சான்றிதழ் சரிபார்ப்பு`
                        : `${activeMeta.titleEn} Official Gateway`}
                    </h3>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      {language === 'ta'
                        ? 'நகராட்சி பணியாளர் கணக்குகள் நிர்வாகி அனுமதியுடன் மட்டுமே செயல்படும்.'
                        : 'Privileged municipal credentials authenticated via PBKDF2 hash ledger.'}
                    </p>
                  </div>
                  <span className="text-[10px] bg-slate-800 text-teal-300 px-2 py-0.5 rounded border border-slate-700 font-mono">
                    Zone 10 HQ
                  </span>
                </div>
              )}

              {/* Error Display */}
              {errorMsg && (
                <div className="mb-4 p-3 bg-rose-950/50 border border-rose-800 text-rose-300 rounded-xl text-xs flex items-start gap-2 animate-fadeIn">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {/* Fast 1-Click Evaluation Bar */}
              {authMode === 'LOGIN' && (
                <div className="mb-5 p-3 rounded-xl bg-gradient-to-r from-teal-950/40 via-slate-900 to-teal-950/40 border border-teal-500/30 flex items-center justify-between gap-3">
                  <div>
                    <span className="text-[11px] font-bold text-teal-300 block flex items-center gap-1.5">
                      <Zap className="w-3.5 h-3.5 text-amber-400" />
                      {language === 'ta' ? 'உடனடி 1-கிளிக் சோதனை உள்நுழைவு:' : '1-Click Evaluator Fast Pass:'}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {language === 'ta'
                        ? `${activePreset.name} கணக்கில் கடவுச்சொல் இன்றி உடனே நுழையலாம்.`
                        : `Instantly test ${activePreset.name} workspace with 1 click.`}
                    </span>
                  </div>
                  <button
                    type="button"
                    disabled={isLoading}
                    onClick={() => handleQuickLogin(selectedRole)}
                    className="bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold px-3 py-1.5 rounded-lg text-xs transition-colors shrink-0 cursor-pointer shadow-md shadow-teal-950 flex items-center gap-1.5 disabled:opacity-50"
                  >
                    <span>{language === 'ta' ? 'உடனே உள்நுழைக' : 'Quick Sign In'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {/* AUTH FORM: LOGIN */}
              {authMode === 'LOGIN' && (
                <form onSubmit={handleLoginSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      {language === 'ta' ? 'மின்னஞ்சல் முகவரி / பணி அடையாள எண்' : 'Official Email / Municipal ID'}
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={e => setEmail(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 focus:border-teal-400 rounded-lg pl-9 pr-3 py-2.5 text-xs text-white outline-hidden font-mono transition-colors"
                        placeholder="name@swasthyagrid.tn.gov.in"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <label className="block text-xs font-semibold text-slate-300">
                        {language === 'ta' ? 'கடவுச்சொல்' : 'Password'}
                      </label>
                      <span className="text-[10px] text-slate-400 font-mono">
                        Demo: <code className="text-teal-400 font-bold">password123</code>
                      </span>
                    </div>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                      <input
                        type={showPassword ? 'text' : 'password'}
                        required
                        value={password}
                        onChange={e => setPassword(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 focus:border-teal-400 rounded-lg pl-9 pr-10 py-2.5 text-xs text-white outline-hidden font-mono transition-colors"
                        placeholder="••••••••••••"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-200 cursor-pointer"
                        title={showPassword ? 'Hide password' : 'Show password'}
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <label className="flex items-center gap-2 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={rememberMe}
                        onChange={e => setRememberMe(e.target.checked)}
                        className="rounded border-slate-700 text-teal-600 focus:ring-teal-500"
                      />
                      <span className="text-[11px]">{language === 'ta' ? '30 நாட்களுக்கு நினைவில் கொள்க' : 'Remember my secure session'}</span>
                    </label>
                    <span className="text-[10px] text-slate-500">
                      HMAC-SHA256 Token
                    </span>
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full bg-teal-600 hover:bg-teal-500 disabled:opacity-50 text-white font-bold py-2.5 rounded-lg text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg shadow-teal-950"
                  >
                    {isLoading ? (
                      <span>{language === 'ta' ? 'சரிபார்க்கப்படுகிறது...' : 'Authenticating Credentials...'}</span>
                    ) : (
                      <>
                        <span>
                          {language === 'ta'
                            ? `${activeMeta.titleTa} தளத்திற்குள் நுழைக`
                            : `Sign In to ${activeMeta.titleEn} Workspace`}
                        </span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </form>
              )}

              {/* AUTH FORM: CITIZEN REGISTRATION */}
              {authMode === 'REGISTER' && (
                <form onSubmit={handleRegisterSubmit} className="space-y-3.5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        {language === 'ta' ? 'முழு பெயர்' : 'Full Name'} *
                      </label>
                      <input
                        type="text"
                        required
                        value={regFullName}
                        onChange={e => setRegFullName(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 focus:border-teal-400 rounded-lg px-3 py-2 text-xs text-white outline-hidden"
                        placeholder="e.g. S. Radhakrishnan"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        {language === 'ta' ? 'மொபைல் எண் (விருப்பத்தேர்வு)' : 'Phone Number (Optional)'}
                      </label>
                      <div className="relative">
                        <Phone className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
                        <input
                          type="tel"
                          value={regPhone}
                          onChange={e => setRegPhone(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 focus:border-teal-400 rounded-lg pl-8 pr-3 py-2 text-xs text-white outline-hidden font-mono"
                          placeholder="9840XXXXXX"
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      {language === 'ta' ? 'மின்னஞ்சல் முகவரி' : 'Email Address'} *
                    </label>
                    <div className="relative">
                      <Mail className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
                      <input
                        type="email"
                        required
                        value={regEmail}
                        onChange={e => setRegEmail(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 focus:border-teal-400 rounded-lg pl-8 pr-3 py-2 text-xs text-white outline-hidden font-mono"
                        placeholder="resident@example.com"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        {language === 'ta' ? 'கடவுச்சொல் (குறைந்தது 6 எழுத்து)' : 'Password (min 6 chars)'} *
                      </label>
                      <input
                        type="password"
                        required
                        value={regPassword}
                        onChange={e => setRegPassword(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 focus:border-teal-400 rounded-lg px-3 py-2 text-xs text-white outline-hidden font-mono"
                        placeholder="••••••••"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        {language === 'ta' ? 'கடவுச்சொல் உறுதிப்படுத்தல்' : 'Confirm Password'} *
                      </label>
                      <input
                        type="password"
                        required
                        value={regConfirmPassword}
                        onChange={e => setRegConfirmPassword(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 focus:border-teal-400 rounded-lg px-3 py-2 text-xs text-white outline-hidden font-mono"
                        placeholder="••••••••"
                      />
                    </div>
                  </div>

                  <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                    <span>
                      {language === 'ta'
                        ? 'கணக்கு பெருநகர சென்னை மாநகராட்சி மண்டலம் 10 (வார்டு 10) வரம்பிற்கு உட்பட்டது.'
                        : 'Registration registers your account for Chennai Central Zone 10 (Ward 10) jurisdiction.'}
                    </span>
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full bg-teal-600 hover:bg-teal-500 disabled:opacity-50 text-white font-bold py-2.5 rounded-lg text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg shadow-teal-950"
                  >
                    {isLoading ? (
                      <span>{language === 'ta' ? 'கணக்கு உருவாக்கப்படுகிறது...' : 'Creating Citizen Account...'}</span>
                    ) : (
                      <>
                        <UserPlus className="w-4 h-4" />
                        <span>
                          {language === 'ta' ? 'குடிமக்கள் கணக்கு உருவாக்கி உள்நுழைக' : 'Create Resident Account & Sign In'}
                        </span>
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>

            {/* Quick Multi-Role Footer Shortcuts */}
            <div className="border-t border-slate-800 pt-4">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block text-center mb-2">
                {language === 'ta' ? 'அனைத்து மாதிரிப் பொறுப்புகளுக்கான நேரடி இணைப்புகள்:' : 'Direct Evaluator Role Switcher:'}
              </span>
              <div className="flex flex-wrap justify-center gap-1.5 sm:gap-2">
                {(Object.keys(PRESET_USERS) as UserRole[]).map(r => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => handleQuickLogin(r)}
                    className={`text-[10px] px-2 py-1 rounded-md border transition-colors cursor-pointer flex items-center gap-1 ${
                      selectedRole === r
                        ? 'bg-teal-950/60 border-teal-500/50 text-teal-300 font-bold'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                    }`}
                  >
                    <span>{PRESET_USERS[r].name.split(' ')[0]}</span>
                    <span className="text-[9px] opacity-70">({r.replace('_', ' ')})</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* 5. Emergency Helpline & Civic Charter Box */}
        <div className="w-full max-w-5xl mt-6 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center gap-3 text-slate-300">
            <div className="p-2 rounded-lg bg-teal-500/10 text-teal-400">
              <Phone className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-white block">GCC Helpline: 1913</span>
              <span className="text-[10px] text-slate-400">24/7 Ward 10 Municipal Grievance</span>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center gap-3 text-slate-300">
            <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400">
              <Building2 className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-white block">CMWSSB: 044-45674567</span>
              <span className="text-[10px] text-slate-400">Water & Sewer Emergency Control</span>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center gap-3 text-slate-300">
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-white block">Tamil Nadu Sanitation</span>
              <span className="text-[10px] text-slate-400">Charter SLA: 24h Triage, 48h Resolution</span>
            </div>
          </div>
        </div>
      </main>

      {/* 6. Legal & Academic Footer */}
      <footer className="border-t border-slate-800/80 py-4 px-4 sm:px-8 text-center text-xs text-slate-500 bg-slate-950/90">
        <p>
          © 2026 SwasthyaGrid (ஸ்வஸ்த்யாகிரிட்) · Academic & Municipal Demonstration · Greater Chennai Corporation
        </p>
      </footer>
    </div>
  );
};
