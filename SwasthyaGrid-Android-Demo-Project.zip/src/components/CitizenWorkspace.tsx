import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CitizenReportWizard } from './CitizenReportWizard';
import { InteractiveCivicMap } from './InteractiveCivicMap';
import { CitizenVerificationView } from './CitizenVerificationView';
import { CivicAIAssistant } from './CivicAIAssistant';
import {
  FileText,
  PlusCircle,
  MapPin,
  CheckCircle2,
  Sparkles,
  Clock,
  Shield,
  ArrowRight,
  ExternalLink,
  AlertTriangle,
} from 'lucide-react';
import { ComplaintStatus } from '../types';

export type CitizenTab = 'my_complaints' | 'report_new' | 'community_map' | 'verify_work' | 'ai_assistant';

export const CitizenWorkspace: React.FC = () => {
  const { currentUser, complaints, t, language } = useApp();
  const [activeTab, setActiveTab] = useState<CitizenTab>('my_complaints');

  // Filter complaints filed by this citizen or relevant to their ward
  const myComplaints = complaints.filter(
    c => c.citizenId === currentUser.id || c.citizenName.includes(currentUser.name.split(' ')[0])
  );

  const awaitingMyVerification = complaints.filter(c => c.status === 'AWAITING_VERIFICATION');

  const getStatusStep = (status: ComplaintStatus): number => {
    switch (status) {
      case 'SUBMITTED':
        return 1;
      case 'UNDER_VALIDATION':
      case 'ACCEPTED':
        return 2;
      case 'ASSIGNED':
      case 'INSPECTION_SCHEDULED':
        return 3;
      case 'ACTION_IN_PROGRESS':
        return 4;
      case 'AWAITING_VERIFICATION':
        return 5;
      case 'RESOLVED':
      case 'CLOSED':
        return 6;
      default:
        return 1;
    }
  };

  return (
    <div className="space-y-6 my-6">
      {/* Citizen Welcome Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white rounded-2xl p-6 border border-slate-700 shadow-xs flex flex-wrap justify-between items-center gap-4">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 bg-teal-500/20 text-teal-300 border border-teal-500/30 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider">
            <span>Citizen Civic Portal</span> · <span>Ward 10 Chennai</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight">
            {language === 'ta' ? `வணக்கம், ${currentUser.name}` : `Welcome, ${currentUser.name}`}
          </h2>
          <p className="text-xs text-slate-300 max-w-xl">
            {language === 'ta'
              ? 'உங்கள் பகுதி சுகாதாரம், சாக்கடை வழிந்தோடுதல் மற்றும் குடிநீர் பிரச்சனைகளை உடனுக்குடன் பதிவு செய்து கண்காணிக்கலாம்.'
              : 'Report neighborhood sanitation hazards, track real-time resolution SLAs, and verify municipal remediation.'}
          </p>
        </div>

        <button
          type="button"
          onClick={() => setActiveTab('report_new')}
          className="bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs px-4 py-2.5 rounded-lg flex items-center gap-2 transition-colors cursor-pointer shadow-md shadow-teal-950"
        >
          <PlusCircle className="w-4 h-4" />
          <span>{language === 'ta' ? 'புதிய புகார் பதிவு செய்க' : 'Report Civic Hazard'}</span>
        </button>
      </div>

      {/* Citizen Exclusive Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto text-xs font-semibold">
        <button
          type="button"
          onClick={() => setActiveTab('my_complaints')}
          className={`px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'my_complaints'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>My Filed Hazards ({myComplaints.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('report_new')}
          className={`px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'report_new'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <PlusCircle className="w-3.5 h-3.5 text-teal-400" />
          <span>Report New Hazard</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('community_map')}
          className={`px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'community_map'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <MapPin className="w-3.5 h-3.5" />
          <span>Community Risk Map</span>
          <span className="text-[10px] bg-teal-100 text-teal-800 px-1.5 py-0.2 rounded font-mono">100m Privacy</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('verify_work')}
          className={`px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'verify_work'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>Verify Completed Work</span>
          {awaitingMyVerification.length > 0 && (
            <span className="bg-amber-100 text-amber-800 text-[10px] px-1.5 py-0.2 rounded font-bold">
              {awaitingMyVerification.length}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('ai_assistant')}
          className={`px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'ai_assistant'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-teal-400" />
          <span>Civic AI Helper</span>
        </button>
      </div>

      {/* Tab 1: My Complaints & Progress Stepper */}
      {activeTab === 'my_complaints' && (
        <div className="space-y-4">
          <div className="flex flex-wrap justify-between items-center gap-3">
            <div>
              <h3 className="font-bold text-base text-slate-900">Personal Incident Submissions</h3>
              <p className="text-xs text-slate-500">
                Track status progression, SLA resolution timers, and assigned municipal officers.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            {myComplaints.map(item => {
              const currentStep = getStatusStep(item.status);
              const steps = [
                'Submitted',
                'Validated',
                'Assigned Unit',
                'In Progress',
                'Citizen Review',
                'Resolved',
              ];

              return (
                <div
                  key={item.id}
                  className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4 hover:border-slate-300 transition-colors"
                >
                  <div className="flex flex-wrap justify-between items-start gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-slate-700">
                          {item.trackingNumber}
                        </span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                            item.currentPriority === 'URGENT'
                              ? 'bg-rose-100 text-rose-800'
                              : item.currentPriority === 'HIGH'
                              ? 'bg-orange-100 text-orange-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {item.currentPriority} Priority
                        </span>
                        <span className="text-xs bg-slate-100 text-slate-700 font-medium px-2 py-0.5 rounded">
                          {t.categories[item.categoryCode as keyof typeof t.categories] || item.categoryCode}
                        </span>
                      </div>
                      <h4 className="font-bold text-base text-slate-900 mt-1">{item.title}</h4>
                      <p className="text-xs text-slate-500 flex items-center gap-1.5 mt-0.5">
                        <MapPin className="w-3 h-3 text-slate-400" /> {item.addressText}
                      </p>
                    </div>

                    <div className="text-right text-xs">
                      <span className="font-mono font-bold text-slate-700 flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-slate-400" /> SLA: {item.hoursElapsed}h / {item.slaDeadlineHours}h
                      </span>
                      <span className="text-[11px] text-slate-400 block mt-0.5">
                        Filed on {new Date(item.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>

                  {/* 6-Stage Resolution Timeline Stepper */}
                  <div className="bg-slate-50 rounded-xl p-3 border border-slate-100">
                    <div className="flex items-center justify-between text-xs mb-2">
                      <span className="font-bold text-slate-700">Municipal Remediation Pipeline:</span>
                      <span className="font-bold text-teal-700">
                        {t.status[item.status] || item.status}
                      </span>
                    </div>

                    <div className="grid grid-cols-6 gap-1 relative">
                      {steps.map((stepLabel, idx) => {
                        const stepNum = idx + 1;
                        const isDone = currentStep >= stepNum;
                        const isCurrent = currentStep === stepNum;

                        return (
                          <div key={idx} className="text-center space-y-1">
                            <div
                              className={`h-2 rounded-full transition-colors ${
                                isDone ? 'bg-teal-600' : 'bg-slate-200'
                              }`}
                            />
                            <span
                              className={`text-[10px] block leading-tight truncate ${
                                isCurrent
                                  ? 'font-bold text-slate-900'
                                  : isDone
                                  ? 'text-teal-800'
                                  : 'text-slate-400'
                              }`}
                            >
                              {stepLabel}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Officer Details & Verification Button if Awaiting */}
                  <div className="flex flex-wrap justify-between items-center pt-1 border-t border-slate-100 text-xs text-slate-600">
                    <div>
                      {item.assignedOfficerName ? (
                        <span>
                          Assigned Officer: <strong>{item.assignedOfficerName}</strong>
                        </span>
                      ) : (
                        <span className="text-amber-700 italic">
                          Queued for Department Officer Assignment
                        </span>
                      )}
                    </div>

                    {item.status === 'AWAITING_VERIFICATION' && (
                      <button
                        type="button"
                        onClick={() => setActiveTab('verify_work')}
                        className="bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" /> Review & Confirm Resolution
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 2: Report Wizard */}
      {activeTab === 'report_new' && (
        <CitizenReportWizard onGoToMap={() => setActiveTab('community_map')} />
      )}

      {/* Tab 3: Community Map */}
      {activeTab === 'community_map' && (
        <InteractiveCivicMap />
      )}

      {/* Tab 4: Verify Work */}
      {activeTab === 'verify_work' && (
        <CitizenVerificationView />
      )}

      {/* Tab 5: AI Assistant */}
      {activeTab === 'ai_assistant' && (
        <CivicAIAssistant />
      )}
    </div>
  );
};
