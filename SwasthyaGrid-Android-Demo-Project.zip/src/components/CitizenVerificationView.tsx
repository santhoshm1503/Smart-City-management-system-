import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CheckCircle2, AlertTriangle, ShieldCheck, MapPin, Clock, MessageSquare } from 'lucide-react';

export const CitizenVerificationView: React.FC = () => {
  const { complaints, updateComplaintStatus, t, language } = useApp();
  const [disputeRemarks, setDisputeRemarks] = useState<string>('');
  const [activeDisputeId, setActiveDisputeId] = useState<string | null>(null);

  const awaitingItems = complaints.filter(c => c.status === 'AWAITING_VERIFICATION');

  const handleConfirm = (id: string) => {
    updateComplaintStatus(id, 'RESOLVED', 'Citizen verified hazard is resolved. Case closed.');
  };

  const handleDispute = (id: string) => {
    if (!disputeRemarks.trim()) return;
    updateComplaintStatus(
      id,
      'REOPENED',
      `Citizen disputed resolution: "${disputeRemarks}". Escalated to Executive Engineer for re-inspection.`
    );
    setDisputeRemarks('');
    setActiveDisputeId(null);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 my-6">
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
        <div className="flex flex-wrap justify-between items-center pb-4 border-b border-slate-200 gap-3">
          <div>
            <span className="text-[11px] font-bold text-teal-700 uppercase tracking-wider block">
              Citizen Feedback Loop
            </span>
            <h3 className="text-xl font-bold text-slate-900 mt-0.5">
              Civic Hazard Resolution Verification
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Field officers have completed municipal interventions for these hazards. As a citizen or neighborhood resident, verify whether the physical hazard has been rectified.
            </p>
          </div>
          <span className="font-mono text-xs font-bold bg-teal-50 text-teal-800 border border-teal-200 px-3 py-1 rounded-full">
            {awaitingItems.length} Awaiting Verification
          </span>
        </div>

        {awaitingItems.length === 0 ? (
          <div className="text-center py-16 text-slate-400 space-y-2">
            <ShieldCheck className="w-12 h-12 text-teal-600/40 mx-auto" />
            <h4 className="font-bold text-slate-700 text-sm">No Pending Verifications</h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              All field interventions have been reviewed. When an officer marks a task complete, it will appear here for community confirmation.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100 mt-4 space-y-4">
            {awaitingItems.map(item => (
              <div key={item.id} className="pt-4 first:pt-0 space-y-3">
                <div className="flex flex-wrap justify-between items-start gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-slate-700">
                        {item.trackingNumber}
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-teal-100 text-teal-800">
                        Remediation Logged
                      </span>
                    </div>
                    <h4 className="font-bold text-sm text-slate-900 mt-1">{item.title}</h4>
                    <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3 h-3 text-slate-400" /> {item.addressText}
                    </p>
                  </div>
                  <span className="text-xs text-slate-500 flex items-center gap-1 font-mono">
                    <Clock className="w-3.5 h-3.5 text-slate-400" /> {item.hoursElapsed}h elapsed
                  </span>
                </div>

                <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs space-y-1.5">
                  <span className="font-bold text-slate-700 block">Officer Intervention Summary:</span>
                  <p className="text-slate-600 leading-relaxed">
                    Assigned Officer <strong>{item.assignedOfficerName || 'Field Unit'}</strong> has completed physical desilting/remediation and recorded resolution proof on the municipal ledger.
                  </p>
                </div>

                {activeDisputeId === item.id ? (
                  <div className="bg-rose-50 border border-rose-200 rounded-lg p-3 space-y-2">
                    <label className="block text-xs font-bold text-rose-900">
                      Explain Why the Hazard Still Persists:
                    </label>
                    <textarea
                      rows={2}
                      value={disputeRemarks}
                      onChange={e => setDisputeRemarks(e.target.value)}
                      placeholder="e.g. Silt was cleared but pipe is still blocked downstream, sewage refilled street within 2 hours..."
                      className="w-full bg-white border border-rose-300 rounded p-2 text-xs outline-hidden"
                    />
                    <div className="flex justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setActiveDisputeId(null);
                          setDisputeRemarks('');
                        }}
                        className="px-3 py-1.5 border border-slate-300 rounded text-xs text-slate-600 hover:bg-white"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        disabled={!disputeRemarks.trim()}
                        onClick={() => handleDispute(item.id)}
                        className="px-4 py-1.5 bg-rose-700 hover:bg-rose-800 disabled:opacity-50 text-white rounded text-xs font-semibold"
                      >
                        Submit Dispute & Reopen
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-wrap items-center justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setActiveDisputeId(item.id)}
                      className="border border-slate-300 hover:bg-slate-50 text-slate-700 px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                    >
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                      {t.forms.disputeResolution}
                    </button>
                    <button
                      type="button"
                      onClick={() => handleConfirm(item.id)}
                      className="bg-teal-700 hover:bg-teal-800 text-white px-5 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      {t.forms.confirmResolution}
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
