import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { UserRole, UserSession, Complaint, AuditLogEntry, CivicIntervention } from '../types';
import { translations } from '../utils/i18n';
import { INITIAL_COMPLAINTS, INITIAL_AUDIT_LOGS, INITIAL_INTERVENTIONS } from '../data/mockData';

export const PRESET_USERS: Record<UserRole, UserSession & { defaultEmail: string; roleLabel: string; roleLabelTa: string }> = {
  CITIZEN: {
    id: 'u-cit-01',
    name: 'M. Anand (ஆனந்த்)',
    email: 'citizen@swasthyagrid.tn.gov.in',
    defaultEmail: 'citizen@swasthyagrid.tn.gov.in',
    role: 'CITIZEN',
    roleLabel: 'Citizen / Resident',
    roleLabelTa: 'குடிமகன் / குடியிருப்புவாசி',
    isDemo: true,
  },
  DEPT_OFFICER: {
    id: 'u-dep-03',
    name: 'R. Priya (பிரியா - AEE Sanitation)',
    email: 'rep@swasthyagrid.tn.gov.in',
    defaultEmail: 'rep@swasthyagrid.tn.gov.in',
    role: 'DEPT_OFFICER',
    roleLabel: 'Ward Representative / Dept Officer',
    roleLabelTa: 'மக்கள் பிரதிநிதி / உதவி செயற்பொறியாளர்',
    departmentCode: 'CMWSSB',
    isDemo: true,
  },
  FIELD_OFFICER: {
    id: 'u-fld-02',
    name: 'K. Selvam (செல்வம்)',
    email: 'field@swasthyagrid.tn.gov.in',
    defaultEmail: 'field@swasthyagrid.tn.gov.in',
    role: 'FIELD_OFFICER',
    roleLabel: 'Municipal Field Officer',
    roleLabelTa: 'நகராட்சி களப்பணி அதிகாரி',
    departmentCode: 'SWD',
    isDemo: true,
  },
  HEALTH_ANALYST: {
    id: 'u-ana-04',
    name: 'Dr. S. Kugan (குகன் - Epidemiologist)',
    email: 'analyst@swasthyagrid.tn.gov.in',
    defaultEmail: 'analyst@swasthyagrid.tn.gov.in',
    role: 'HEALTH_ANALYST',
    roleLabel: 'Health & Risk Analyst',
    roleLabelTa: 'சுகாதார இடர் பகுப்பாய்வாளர்',
    isDemo: true,
  },
  SYS_ADMIN: {
    id: 'u-adm-05',
    name: 'Sundararajan (நிர்வாக அதிகாரி)',
    email: 'admin@swasthyagrid.tn.gov.in',
    defaultEmail: 'admin@swasthyagrid.tn.gov.in',
    role: 'SYS_ADMIN',
    roleLabel: 'System Administrator',
    roleLabelTa: 'கணினி தலைமை நிர்வாகி',
    isDemo: true,
  },
};

interface ToastNotification {
  id: string;
  type: 'success' | 'info' | 'warning' | 'error';
  message: string;
}

interface AppContextType {
  isAuthenticated: boolean;
  currentUser: UserSession;
  language: 'en' | 'ta';
  t: (typeof translations)['en'];
  complaints: Complaint[];
  auditLogs: AuditLogEntry[];
  interventions: CivicIntervention[];
  activeToast: ToastNotification | null;
  setLanguage: (lang: 'en' | 'ta') => void;
  login: (email: string, password?: string, role?: UserRole) => Promise<boolean>;
  registerCitizen: (email: string, password: string, fullName: string, phone?: string) => Promise<boolean>;
  logout: () => void;
  showToast: (message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
  addComplaint: (complaint: Partial<Complaint>) => Promise<Complaint>;
  updateComplaintStatus: (id: string, status: Complaint['status'], remarks?: string, assignedOfficer?: string) => Promise<void>;
  addIntervention: (intervention: Partial<CivicIntervention>) => Promise<void>;
  refreshData: () => Promise<void>;
}

const DEMO_OFFLINE_MODE = true; // Assignment demo APK: no live municipal backend required.

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<'en' | 'ta'>('en');

  // Load authentication from localStorage if present
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    try {
      return localStorage.getItem('sg_authenticated') === 'true';
    } catch {
      return false;
    }
  });

  const [currentUser, setCurrentUser] = useState<UserSession>(() => {
    try {
      const stored = localStorage.getItem('sg_current_user');
      if (stored) return JSON.parse(stored);
    } catch {
      // Fallback
    }
    return PRESET_USERS.CITIZEN;
  });

  const [complaints, setComplaints] = useState<Complaint[]>(() => {
    try { return JSON.parse(localStorage.getItem('sg_demo_complaints') || 'null') || INITIAL_COMPLAINTS; }
    catch { return INITIAL_COMPLAINTS; }
  });
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(() => {
    try { return JSON.parse(localStorage.getItem('sg_demo_audit') || 'null') || INITIAL_AUDIT_LOGS; }
    catch { return INITIAL_AUDIT_LOGS; }
  });
  const [interventions, setInterventions] = useState<CivicIntervention[]>(() => {
    try { return JSON.parse(localStorage.getItem('sg_demo_interventions') || 'null') || INITIAL_INTERVENTIONS; }
    catch { return INITIAL_INTERVENTIONS; }
  });
  useEffect(() => {
    try {
      localStorage.setItem('sg_demo_complaints', JSON.stringify(complaints));
      localStorage.setItem('sg_demo_audit', JSON.stringify(auditLogs));
      localStorage.setItem('sg_demo_interventions', JSON.stringify(interventions));
    } catch (error) {
      console.warn('Unable to persist local demo data:', error);
    }
  }, [complaints, auditLogs, interventions]);
  const [activeToast, setActiveToast] = useState<ToastNotification | null>(null);

  const showToast = useCallback((message: string, type: 'success' | 'info' | 'warning' | 'error' = 'info') => {
    const id = Math.random().toString(36).substring(2, 9);
    setActiveToast({ id, type, message });
    setTimeout(() => {
      setActiveToast(prev => (prev?.id === id ? null : prev));
    }, 4500);
  }, []);

  const refreshData = useCallback(async () => {
    if (DEMO_OFFLINE_MODE) return;
    try {
      const res = await fetch('/api/complaints');
      if (res.ok) {
        const data = await res.json();
        setComplaints(data);
      }
    } catch {
      // Keep state if offline
    }

    try {
      const resAudit = await fetch('/api/audit-logs');
      if (resAudit.ok) {
        const logs = await resAudit.json();
        setAuditLogs(logs);
      }
    } catch {
      // Keep state if offline
    }
  }, []);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  const login = async (email: string, password: string = 'password123', role?: UserRole): Promise<boolean> => {
    if (DEMO_OFFLINE_MODE) {
      const selectedRole = role || (Object.keys(PRESET_USERS) as UserRole[]).find(
        key => PRESET_USERS[key].defaultEmail.toLowerCase() === email.toLowerCase()
      ) || 'CITIZEN';
      const user = { ...PRESET_USERS[selectedRole], email: PRESET_USERS[selectedRole].defaultEmail };
      setCurrentUser(user);
      setIsAuthenticated(true);
      localStorage.setItem('sg_authenticated', 'true');
      localStorage.setItem('sg_current_user', JSON.stringify(user));
      showToast(`Demo access: ${user.roleLabel}`, 'success');
      return true;
    }
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, role }),
      });

      if (res.ok) {
        const data = await res.json();
        setCurrentUser(data.user);
        setIsAuthenticated(true);
        localStorage.setItem('sg_authenticated', 'true');
        localStorage.setItem('sg_current_user', JSON.stringify(data.user));
        if (data.token) {
          localStorage.setItem('sg_token', data.token);
        }
        showToast(
          language === 'ta'
            ? `${data.user.name} ஆக வெற்றிகரமாக உள்நுழைந்துள்ளீர்கள்!`
            : `Welcome back, ${data.user.name}! Logged in as ${data.user.role}.`,
          'success'
        );
        refreshData();
        return true;
      } else {
        const err = await res.json();
        showToast(err.error || 'Authentication failed. Please check credentials.', 'error');
        return false;
      }
    } catch {
      // Fallback local authentication
      const selected = role ? PRESET_USERS[role] : PRESET_USERS.CITIZEN;
      const user = { ...selected, email };
      setCurrentUser(user);
      setIsAuthenticated(true);
      localStorage.setItem('sg_authenticated', 'true');
      localStorage.setItem('sg_current_user', JSON.stringify(user));
      showToast(`Logged in as ${user.name} (${user.role})`, 'success');
      return true;
    }
  };

  const registerCitizen = async (email: string, password: string, fullName: string, phone?: string): Promise<boolean> => {
    if (DEMO_OFFLINE_MODE) {
      const user: UserSession = {
        id: `demo-citizen-${Date.now()}`,
        name: fullName || 'Demo Citizen',
        email,
        role: 'CITIZEN',
        isDemo: true,
      };
      setCurrentUser(user);
      setIsAuthenticated(true);
      localStorage.setItem('sg_authenticated', 'true');
      localStorage.setItem('sg_current_user', JSON.stringify(user));
      showToast('Demo citizen profile created on this device.', 'success');
      return true;
    }
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, fullName, phone }),
      });

      if (res.ok) {
        const data = await res.json();
        setCurrentUser(data.user);
        setIsAuthenticated(true);
        localStorage.setItem('sg_authenticated', 'true');
        localStorage.setItem('sg_current_user', JSON.stringify(data.user));
        if (data.token) {
          localStorage.setItem('sg_token', data.token);
        }
        showToast(
          language === 'ta'
            ? `வணக்கம் ${data.user.name}! உங்கள் குடிமக்கள் கணக்கு உருவாக்கப்பட்டது.`
            : `Welcome, ${data.user.name}! Your citizen account has been created.`,
          'success'
        );
        refreshData();
        return true;
      } else {
        const err = await res.json();
        showToast(err.error || 'Registration failed.', 'error');
        return false;
      }
    } catch {
      showToast('Network error during registration.', 'error');
      return false;
    }
  };

  const logout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('sg_authenticated');
    localStorage.removeItem('sg_current_user');
    localStorage.removeItem('sg_token');
    showToast(language === 'ta' ? 'வெற்றிகரமாக வெளியேறிவிட்டீர்கள்.' : 'You have been safely signed out.', 'info');
  };

  const addComplaint = async (input: Partial<Complaint>): Promise<Complaint> => {
    if (!DEMO_OFFLINE_MODE) try {
      const token = localStorage.getItem('sg_token');
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch('/api/complaints', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          ...input,
          citizenId: currentUser.id,
          citizenName: currentUser.name,
        }),
      });

      if (res.ok) {
        const created: Complaint = await res.json();
        setComplaints(prev => [created, ...prev]);
        showToast(`Complaint registered with ID: ${created.trackingNumber}`, 'success');
        refreshData();
        return created;
      }
    } catch (err) {
      console.warn('Network error registering complaint on server; using local persistence', err);
    }

    // Local fallback
    const trackingNumber = `SG-TN-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;
    const fallbackComplaint: Complaint = {
      id: `cmp-${Date.now()}`,
      trackingNumber,
      citizenId: currentUser.id,
      citizenName: currentUser.name,
      categoryId: input.categoryId || 'cat-1',
      categoryCode: input.categoryCode || 'garbage_accumulation',
      departmentCode: input.departmentCode || 'SWM',
      wardNumber: 10,
      wardName: 'Ward 10 - Chennai Central',
      title: input.title || 'Civic Incident',
      description: input.description || '',
      status: 'SUBMITTED',
      currentPriority: input.currentPriority || 'MODERATE',
      priorityScore: input.priorityScore || 0.55,
      lat: input.lat || 13.0827,
      lng: input.lng || 80.2707,
      addressText: input.addressText || 'Ward 10, Chennai Central',
      imageUrl: input.imageUrl,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      observedAt: new Date().toISOString(),
      requiresHumanReview: Boolean(input.requiresHumanReview),
      slaDeadlineHours: 24,
      hoursElapsed: 0,
      independentReportsCount: 1,
      proximityRiskLevel: 'MEDIUM',
      aiSummary: input.aiSummary,
      aiObservations: input.aiObservations,
      aiMissingInfo: input.aiMissingInfo,
      aiLimitations: input.aiLimitations,
    };

    setComplaints(prev => [fallbackComplaint, ...prev]);
    showToast(`Complaint registered locally with ID: ${trackingNumber}`, 'success');
    return fallbackComplaint;
  };

  const updateComplaintStatus = async (
    id: string,
    status: Complaint['status'],
    remarks?: string,
    assignedOfficer?: string
  ) => {
    if (!DEMO_OFFLINE_MODE) try {
      const token = localStorage.getItem('sg_token');
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(`/api/complaints/${id}/status`, {
        method: 'PATCH',
        headers,
        body: JSON.stringify({
          status,
          remarks,
          actorName: currentUser.name,
          actorRole: currentUser.role,
          assignedOfficerName: assignedOfficer,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const updated = data.complaint;
        setComplaints(prev => prev.map(c => (c.id === id ? updated : c)));
        showToast(`Status updated to ${status.replace(/_/g, ' ')}`, 'success');
        refreshData();
        return;
      } else {
        const err = await res.json();
        showToast(err.error || `Unable to update to ${status}`, 'error');
        return;
      }
    } catch {
      // Local fallback
    }

    setComplaints(prev =>
      prev.map(c =>
        c.id === id
          ? {
              ...c,
              status,
              assignedOfficerName: assignedOfficer !== undefined ? assignedOfficer : c.assignedOfficerName,
              updatedAt: new Date().toISOString(),
            }
          : c
      )
    );
    showToast(`Status updated to ${status}`, 'success');
  };

  const addIntervention = async (intervention: Partial<CivicIntervention>) => {
    const newInt: CivicIntervention = {
      id: `int-${Date.now()}`,
      complaintId: intervention.complaintId || 'cmp-target',
      trackingNumber: intervention.trackingNumber || 'SG-TN-TARGET',
      interventionType: intervention.interventionType || 'DESILTING',
      description: intervention.description || '',
      completedAt: new Date().toISOString(),
      officerName: currentUser.name,
      baselineWindowDays: intervention.baselineWindowDays || 14,
      evaluationWindowDays: intervention.evaluationWindowDays || 14,
      baselineIncidentCount: intervention.baselineIncidentCount || 10,
      postIncidentCount: intervention.postIncidentCount || 2,
      rainfallShiftMm: intervention.rainfallShiftMm,
      trendVerdict: intervention.trendVerdict || 'IMPROVING',
      confidenceRating: intervention.confidenceRating || 'HIGH',
      identifiedConfounders: intervention.identifiedConfounders || [],
      recommendation: intervention.recommendation || 'Maintain standard schedule.',
    };

    setInterventions(prev => [newInt, ...prev]);
    showToast('Field intervention logged successfully on municipal ledger', 'success');
  };

  return (
    <AppContext.Provider
      value={{
        isAuthenticated,
        currentUser,
        language,
        t: translations[language],
        complaints,
        auditLogs,
        interventions,
        activeToast,
        setLanguage,
        login,
        registerCitizen,
        logout,
        showToast,
        addComplaint,
        updateComplaintStatus,
        addIntervention,
        refreshData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within an AppProvider');
  return ctx;
};
